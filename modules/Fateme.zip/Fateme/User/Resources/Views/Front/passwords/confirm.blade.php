@extends('User::Front.master')

@section('content')
@endsection
