<div class="breadcrumb">
    <ul>
        <li><a href="{{route('home')}}" title="پیشخوان">پیشخوان</a></li>
    </ul>
</div>
