<?php

namespace Fateme\User\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class validMobile implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail):void
    {
//        dd($value);
        if (!preg_match("/^9[0-9]{9}$/", $value)) {
            $fail('فرمت موبایل نامعتبر است');
        }

    }
}
