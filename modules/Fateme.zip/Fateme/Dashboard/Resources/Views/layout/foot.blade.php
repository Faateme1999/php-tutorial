<script src="/panel/js/jquery-3.4.1.min.js"></script>
<script src="/panel/js/js.js"></script>

@yield('js')
